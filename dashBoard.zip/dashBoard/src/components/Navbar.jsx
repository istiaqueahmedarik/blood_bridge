import React from 'react';
import '../styles/global.css';
import logo from '../assets/images/logo.png';
import bellIcon from '../assets/images/bellIcon.png';

export default function Navbar() {
    return (
        <nav className='navbar'>
            <img src={logo} alt="Image not available" className="logo" />
            <div className='nav-page-link'>Donor</div>
            <div className='nav-page-link'>Blood Bank</div>
            <div className='nav-page-link'>Medical</div>
            <div className='nav-page-link'>Ask</div>
            <button className='btn btn-black-nav'>Choose User</button>
            <button className='btn btn-red-nav'>Alert</button>
            <img src={bellIcon} alt="Image not available" className="bellIcon" />
        </nav>
    );
}