import '../styles/global.css';
import logo from '../assets/images/logo.png';
import bellIcon from '../assets/images/bellIcon.png';
import face from '../assets/images/face.png';
import dashImg from '../assets/images/dashImg.png';
import editImg from '../assets/images/editImg.png';
import donations from '../assets/images/donations.png';
import Navbar from './Navbar';

export default function Donor() {
    return <div>
        <Navbar />
        <div className="cards-container">
            <div className="account-card">
                <div className="account-info">
                    <img src={face} alt="Loading Image" className='face' />
                    <div className="account-name">Robert Downey</div>
                    <div className='account-blood-group'>Blood Group: O+</div>
                </div>
                <div className="account-card-options">
                    <div className="account-card-options-dashboard">
                        <img src={dashImg} alt="Avatar" className='account-card-options-img' />
                        <div className='account-card-options-desc'>Dashboard</div>
                    </div>
                </div>
                <div className="account-card-options">
                    <div className="account-card-options-dashboard">
                        <img src={editImg} alt="Avatar" className='account-card-options-img' />
                        <div className='account-card-options-desc'>Edit Profile</div>
                    </div>
                </div>
            </div>
            <div className="card-column">
                <div className="record-card-primary">
                    <div className="record-card">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Total Donations</span>
                                <div className="record-card-info-writing-desc">12</div>
                            </div>
                            <img src={donations} alt="Loading mage" className="record-card-info-img-donor" />
                        </div>
                    </div>
                    <div className="record-card">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Last Donation</span>
                                <div className="record-card-info-writing-desc">2 Months</div>
                            </div>
                            <img src={donations} alt="Loading mage" className="record-card-info-img-donor" />
                        </div>
                    </div>
                    <div className="record-card">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Lives Saved</span>
                                <div className="record-card-info-writing-desc">36</div>
                            </div>
                            <img src={donations} alt="Loading mage" className="record-card-info-img-donor" />
                        </div>
                    </div>
                    <div className="record-card">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Next Eligible Date</span>
                                <div className="record-card-info-writing-desc">05/03/2024</div>
                            </div>
                            <img src={donations} alt="Loading mage" className="record-card-info-img-donor" />
                        </div>
                    </div>
                </div>
                <div className="activity-setion">
                    <div className="activity-setion-title">
                        <ul>
                            <li>Dashboard</li>
                            <li>Appoinments</li>
                            <li>Donation History</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
}