import Navbar from "./Navbar";
import '../styles/global.css';
import logo from '../assets/images/logo.png';
import bellIcon from '../assets/images/bellIcon.png';
import face from '../assets/images/face.png';
import dashImg from '../assets/images/dashImg.png';
import editImg from '../assets/images/editImg.png';
import donations from '../assets/images/donations.png';
import bloodUnits from '../assets/images/bloodUnits.png';
import timer from '../assets/images/timer.png';
import success from '../assets/images/success.png';
import requestImg from '../assets/images/requestImg.png';
import sliderOne from '../assets/images/sliderOne.png';
import sliderTwo from '../assets/images/sliderTwo.png';
import sliderThree from '../assets/images/sliderThree.png';

export default function Medical() {
    return <div>
        <Navbar />
        <div className="cards-container">
            <div className="account-card account-card-med">
                <div className="account-card-med-service">
                    <div className="account-card-med-service-title">Alif Medical Center</div>
                    <ul className="account-card-med-service-list">
                        <li>Dashboard</li>
                        <li>Blood Requests</li>
                        <li>Request History</li>
                        <li>Invenotry</li>
                        <li>Request Blood</li>
                    </ul>
                </div>
            </div>
            <div className="card-column card-column-med">
                <div className="record-card-primary record-card-primary-med">
                    <div className="record-card-med">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Available Blood Units</span>
                                <div className="record-card-info-writing-desc">12</div>
                                <div className="record-card-info-footer">
                                    +12% from last month
                                </div>
                            </div>
                            <img src={bloodUnits} alt="Loading image" className="record-card-info-img-med" />
                        </div>
                    </div>
                    <div className="record-card-med">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Pending Request</span>
                                <div className="record-card-info-writing-desc">23</div>
                                <div className="record-card-info-footer">
                                    8 urgent requests
                                </div>
                            </div>
                            <img src={timer} alt="Loading image" className="record-card-info-img-med" />
                        </div>
                    </div>
                    <div className="record-card-med">
                        <div className="record-card-info">
                            <div className="record-card-info-writing">
                                <span>Successful Donations</span>
                                <div className="record-card-info-writing-desc">1284</div>
                                <div className="record-card-info-footer">
                                    This Year
                                </div>
                            </div>
                            <img src={success} alt="Loading mage" className="record-card-info-img-med" />
                        </div>
                    </div>
                </div>
                <div className="med-request-inventory-cards">
                    <div className="request-card">
                        <div className="request-card-heading">
                            <div className="request-card-heading-header">Recent Blood Request</div>
                            <div className="request-card-heading-header-option">View all</div>
                        </div>
                        <div className="request-card-body">    
                            <div className="request-card-body-contents">
                                <img src={requestImg} alt="Request Image" className="request-card-body-img" />
                                <div className="request-card-body-bGroup-section">
                                    <div className="request-card-body-bGroup-section-group">A+ Blood Required</div>
                                    <div className="request-card-body-bGroup-section-place">City Hospital - Emergency</div>
                                </div>
                                <button className="request-card-body-button">Accept</button>
                            </div>
                            <div className="request-card-body-contents">
                                <img src={requestImg} alt="Request Image" className="request-card-body-img" />
                                <div className="request-card-body-bGroup-section">
                                    <div className="request-card-body-bGroup-section-group">O- Blood Required</div>
                                    <div className="request-card-body-bGroup-section-place">Metro Hospital - Surgery</div>
                                </div>
                                <button className="request-card-body-button">Accept</button>
                            </div>
                            <div className="request-card-body-contents">
                                <img src={requestImg} alt="Request Image" className="request-card-body-img" />
                                <div className="request-card-body-bGroup-section">
                                    <div className="request-card-body-bGroup-section-group">O- Blood Required</div>
                                    <div className="request-card-body-bGroup-section-place">Metro Hospital - Surgery</div>
                                </div>
                                <button className="request-card-body-button">Accept</button>
                            </div>
                        </div>
                    </div>
                    <div className="request-card inventory-card">
                        <div className="request-card-heading">
                            <div className="request-card-heading-header">Blood Inventory Status</div>
                        </div>
                        <div className="request-card-body inventory-card-body">
                            <div className="inventory-card-body-contents">
                                <div className="inventory-card-bGroup">A+</div>
                                <img src={sliderOne} alt="Slider Image" className="slider" />
                                <div className="percent">75%</div>
                            </div>
                            <div className="inventory-card-body-contents">
                                <div className="inventory-card-bGroup">B+</div>
                                <img src={sliderTwo} alt="Slider Image" className="slider" />
                                <div className="percent">50%</div>
                            </div>
                            <div className="inventory-card-body-contents">
                                <div className="inventory-card-bGroup">AB+</div>
                                <img src={sliderThree} alt="Slider Image" className="slider" />
                                <div className="percent">25%</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
}