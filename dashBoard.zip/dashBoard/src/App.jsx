import { useState } from 'react'
import Donor from './components/Donor'
import Medical from './components/Medical'
import Navbar from './components/Navbar'

function App() {
  return (
    <>
      {/* <Donor /> */}
      <Medical />
      {/* <Navbar /> */}
    </>
  )
}

export default App
